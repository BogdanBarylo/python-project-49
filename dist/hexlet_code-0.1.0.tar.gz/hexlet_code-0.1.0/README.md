### Hexlet tests and linter status:
[![Actions Status](https://github.com/BogdanBarylo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/BogdanBarylo/python-project-49/actions)
[!Asciinema] https://asciinema.org/a/YQ5xhbM1kW4ArgDkb5Bl0Zt9Z