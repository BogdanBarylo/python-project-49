### Hexlet tests and linter status:
[![Actions Status](https://github.com/BogdanBarylo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/BogdanBarylo/python-project-49/actions)
#asciinema brain-even https://asciinema.org/a/YQ5xhbM1kW4ArgDkb5Bl0Zt9Z
#asciinema brain-calc https://asciinema.org/a/E3udXd1PvdZqCvQ68ACDfeJ7Q
#asciinema brain-gcd https://asciinema.org/a/VAQzgia7gZCuk9wxztw57YIbb
#asciinema brain-progression https://asciinema.org/a/S8KNyibH5QuTiRnBsp57Oi4Ol